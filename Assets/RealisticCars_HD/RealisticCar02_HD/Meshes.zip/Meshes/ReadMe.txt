This folder contains all meshes for car wheels etc. 

I've put here separated fbx files for each LOD just in case If You would like to use them in another way. 

All RealisticCar02 prefabs use RealisticCar02_HD_Complete.fbx file, it contains all LODs, 4wheels, lights etc. 
